
import React from 'react';
import { Sun, Moon, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

interface HeaderProps {
  toggleHistoryDrawer: () => void;
}

const Header: React.FC<HeaderProps> = ({ toggleHistoryDrawer }) => {
  const [isDarkMode, setIsDarkMode] = React.useState(
    window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
  );
  const { toast } = useToast();

  React.useEffect(() => {
    const root = window.document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
    toast({
      title: isDarkMode ? "Light mode activated" : "Dark mode activated",
      duration: 1500,
    });
  };

  return (
    <header className="w-full py-4 px-6 glass-morphism fixed top-0 left-0 right-0 z-50 flex justify-between items-center animate-slide-down">
      <div className="flex items-center space-x-2">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={toggleHistoryDrawer}
          className="transition-all duration-300 hover:bg-primary/10"
        >
          <Menu className="h-5 w-5" />
        </Button>
        <h1 className="text-xl md:text-2xl font-serif tracking-tight">
          Verse<span className="text-primary font-medium">Simplifier</span>
        </h1>
      </div>
      <Button
        variant="ghost"
        size="icon"
        onClick={toggleTheme}
        className="rounded-full transition-all duration-300 hover:bg-primary/10"
      >
        {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
      </Button>
    </header>
  );
};

export default Header;
