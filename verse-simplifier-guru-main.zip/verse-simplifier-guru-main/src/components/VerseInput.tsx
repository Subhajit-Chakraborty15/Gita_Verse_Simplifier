
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { SearchIcon, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';

interface VerseInputProps {
  onSubmit: (verse: string) => void;
  isLoading: boolean;
}

const VerseInput: React.FC<VerseInputProps> = ({ onSubmit, isLoading }) => {
  const [verse, setVerse] = useState('');
  const { toast } = useToast();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!verse.trim()) {
      toast({
        variant: "destructive",
        title: "Input required",
        description: "Please enter a verse to simplify.",
      });
      return;
    }
    
    onSubmit(verse);
  };

  return (
    <form 
      onSubmit={handleSubmit} 
      className="w-full max-w-2xl mx-auto p-6 rounded-xl glass-morphism transition-all duration-300 hover:shadow-elevated"
    >
      <div className="mb-4">
        <h2 className="text-lg font-medium mb-2 font-serif">Enter Verse Reference or Content</h2>
        <p className="text-sm text-muted-foreground">
          Enter a verse reference (e.g., "Bhagavad-gita 2.47") or the actual verse content to receive a simplified explanation.
        </p>
      </div>
      
      <Textarea
        value={verse}
        onChange={(e) => setVerse(e.target.value)}
        placeholder="Enter verse reference or content..."
        className="min-h-[120px] resize-none bg-white/50 dark:bg-black/50 backdrop-blur-sm transition-all duration-300 focus:bg-white/80 dark:focus:bg-black/80 focus:ring-1 ring-primary/30"
      />
      
      <div className="mt-4 flex justify-end">
        <Button 
          type="submit"
          disabled={isLoading} 
          className="relative overflow-hidden group"
        >
          {isLoading ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Simplifying...
            </>
          ) : (
            <>
              <SearchIcon className="mr-2 h-4 w-4" />
              Simplify Verse
            </>
          )}
          <span className="absolute inset-0 bg-primary/10 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300"></span>
        </Button>
      </div>
    </form>
  );
};

export default VerseInput;
