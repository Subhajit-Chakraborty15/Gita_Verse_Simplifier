
import React, { useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { ChevronDown, ChevronUp, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';

interface ExplanationCardProps {
  verse: string;
  explanation: string;
  isLoading: boolean;
}

const LoadingPlaceholder = () => (
  <div className="space-y-4 relative overflow-hidden">
    <div className="h-6 bg-secondary/70 rounded w-1/3 relative overflow-hidden">
      <div className="absolute inset-0 loading-shimmer"></div>
    </div>
    <div className="h-4 bg-secondary/70 rounded w-2/3 relative overflow-hidden">
      <div className="absolute inset-0 loading-shimmer"></div>
    </div>
    <div className="space-y-2">
      <div className="h-20 bg-secondary/70 rounded relative overflow-hidden">
        <div className="absolute inset-0 loading-shimmer"></div>
      </div>
      <div className="h-20 bg-secondary/70 rounded relative overflow-hidden">
        <div className="absolute inset-0 loading-shimmer"></div>
      </div>
    </div>
  </div>
);

const ExplanationCard: React.FC<ExplanationCardProps> = ({ verse, explanation, isLoading }) => {
  const [copied, setCopied] = React.useState(false);
  const [expanded, setExpanded] = React.useState(false);
  const contentRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const copyToClipboard = () => {
    navigator.clipboard.writeText(explanation);
    setCopied(true);
    toast({
      title: "Copied to clipboard",
      duration: 1500,
    });
    
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleExpanded = () => {
    setExpanded(!expanded);
  };

  useEffect(() => {
    // Reset the expanded state when a new explanation is loaded
    setExpanded(false);
  }, [explanation]);

  const isContentOverflowing = () => {
    if (contentRef.current) {
      return contentRef.current.scrollHeight > 300;
    }
    return false;
  };

  if (isLoading) {
    return (
      <Card className="w-full max-w-2xl mx-auto mt-8 overflow-hidden glass-morphism animate-fade-in">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Simplifying...</CardTitle>
        </CardHeader>
        <Separator />
        <CardContent className="pt-4">
          <LoadingPlaceholder />
        </CardContent>
      </Card>
    );
  }

  if (!explanation) return null;

  return (
    <Card className="w-full max-w-2xl mx-auto mt-8 overflow-hidden glass-morphism animate-fade-in">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg font-medium">Simplified Explanation</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">Based on Vedabase references</p>
          </div>
          <Badge variant="outline" className="bg-primary/10 text-xs">
            AI Generated
          </Badge>
        </div>
      </CardHeader>
      <Separator />
      <CardContent className="pt-4">
        <div className="mb-4 p-3 bg-secondary/30 rounded-md text-sm italic">
          <p className="font-medium text-muted-foreground">{verse}</p>
        </div>
        
        <div 
          className={`relative ${!expanded ? 'max-h-[300px]' : 'max-h-none'} overflow-hidden transition-all duration-500`}
        >
          <div 
            ref={contentRef}
            className="prose prose-sm dark:prose-invert max-w-none"
            dangerouslySetInnerHTML={{ __html: explanation.replace(/\n/g, '<br/>') }}
          />
          
          {!expanded && isContentOverflowing() && (
            <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-background to-transparent"></div>
          )}
        </div>
        
        {isContentOverflowing() && (
          <Button 
            variant="ghost" 
            onClick={toggleExpanded} 
            className="mt-4 w-full text-sm text-muted-foreground hover:text-foreground transition-all"
          >
            {expanded ? (
              <>Show less <ChevronUp className="ml-2 h-4 w-4" /></>
            ) : (
              <>Show more <ChevronDown className="ml-2 h-4 w-4" /></>
            )}
          </Button>
        )}
        
        <div className="mt-4 flex justify-end">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={copyToClipboard}
            className="text-xs"
          >
            {copied ? (
              <>
                <Check className="mr-2 h-3 w-3" />
                Copied
              </>
            ) : (
              <>
                <Copy className="mr-2 h-3 w-3" />
                Copy explanation
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ExplanationCard;
