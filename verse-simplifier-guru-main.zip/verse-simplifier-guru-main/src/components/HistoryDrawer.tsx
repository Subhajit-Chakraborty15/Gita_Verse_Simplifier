
import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Trash2 } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/components/ui/use-toast';

export interface HistoryItem {
  id: string;
  verse: string;
  timestamp: Date;
}

interface HistoryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  historyItems: HistoryItem[];
  onSelectItem: (item: HistoryItem) => void;
  onClearHistory: () => void;
}

const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  isOpen,
  onClose,
  historyItems,
  onSelectItem,
  onClearHistory,
}) => {
  const { toast } = useToast();

  const handleClearHistory = () => {
    onClearHistory();
    toast({
      description: "Search history cleared",
      duration: 2000,
    });
  };

  const formatTimestamp = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      hour: 'numeric',
      minute: 'numeric',
      day: 'numeric',
      month: 'short',
    }).format(date);
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="left" className="sm:max-w-md glass-morphism">
        <SheetHeader className="mb-4">
          <SheetTitle className="font-serif text-xl">Search History</SheetTitle>
        </SheetHeader>

        <div className="flex justify-end mb-4">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleClearHistory}
            className="text-xs text-muted-foreground hover:text-destructive"
            disabled={historyItems.length === 0}
          >
            <Trash2 className="h-3.5 w-3.5 mr-1" />
            Clear history
          </Button>
        </div>

        <Separator className="mb-4" />

        {historyItems.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground animate-fade-in">
            <p>No search history yet</p>
            <p className="text-xs mt-1">Your searched verses will appear here</p>
          </div>
        ) : (
          <ScrollArea className="h-[calc(100vh-160px)] elegant-scroll pr-4">
            <div className="space-y-3">
              {historyItems.map((item) => (
                <Button
                  key={item.id}
                  variant="ghost"
                  className="w-full justify-start h-auto py-3 text-left flex flex-col items-start gap-1 hover:bg-primary/5 transition-colors"
                  onClick={() => onSelectItem(item)}
                >
                  <span className="line-clamp-2 text-sm">{item.verse}</span>
                  <span className="text-xs text-muted-foreground">{formatTimestamp(item.timestamp)}</span>
                </Button>
              ))}
            </div>
          </ScrollArea>
        )}
      </SheetContent>
    </Sheet>
  );
};

export default HistoryDrawer;
