
import React, { useState, useEffect } from 'react';
import VerseInput from '@/components/VerseInput';
import ExplanationCard from '@/components/ExplanationCard';
import Header from '@/components/Header';
import HistoryDrawer, { HistoryItem } from '@/components/HistoryDrawer';
import { simplifyVerse } from '@/utils/api';
import { v4 as uuidv4 } from 'uuid';
import { useToast } from '@/components/ui/use-toast';

const LOCAL_STORAGE_KEY = 'verse-simplifier-history';

const Index = () => {
  const [verse, setVerse] = useState('');
  const [explanation, setExplanation] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const { toast } = useToast();

  // Load history from localStorage on component mount
  useEffect(() => {
    const savedHistory = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (savedHistory) {
      try {
        const parsedHistory = JSON.parse(savedHistory);
        // Convert string timestamps back to Date objects
        const historyWithDates = parsedHistory.map((item: any) => ({
          ...item,
          timestamp: new Date(item.timestamp)
        }));
        setHistory(historyWithDates);
      } catch (e) {
        console.error('Error parsing history from localStorage:', e);
      }
    }
  }, []);

  // Save history to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(history));
  }, [history]);

  const handleVerseSubmit = async (inputVerse: string) => {
    setVerse(inputVerse);
    setIsLoading(true);
    
    try {
      const response = await simplifyVerse(inputVerse);
      setExplanation(response.explanation);
      
      // Add to history
      const newHistoryItem: HistoryItem = {
        id: uuidv4(),
        verse: inputVerse,
        timestamp: new Date()
      };
      
      setHistory(prev => [newHistoryItem, ...prev]);
      
    } catch (error) {
      console.error('Error:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to simplify verse. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectHistoryItem = (item: HistoryItem) => {
    setVerse(item.verse);
    handleVerseSubmit(item.verse);
    setIsHistoryOpen(false);
  };

  const handleClearHistory = () => {
    setHistory([]);
  };

  return (
    <div className="min-h-screen bg-gradient-radial from-background to-muted/30 flex flex-col items-center">
      <Header toggleHistoryDrawer={() => setIsHistoryOpen(!isHistoryOpen)} />
      
      <main className="w-full max-w-4xl px-4 pt-24 pb-16 flex flex-col items-center">
        <div className="w-full max-w-2xl mb-10 text-center animate-fade-in">
          <h1 className="text-3xl md:text-4xl font-serif font-medium mb-3">Verse Simplifier</h1>
          <p className="text-muted-foreground max-w-md mx-auto">
            Enter a verse to receive a simplified explanation based on Vedabase references.
          </p>
        </div>
        
        <VerseInput 
          onSubmit={handleVerseSubmit} 
          isLoading={isLoading} 
        />
        
        {(explanation || isLoading) && (
          <ExplanationCard 
            verse={verse}
            explanation={explanation}
            isLoading={isLoading}
          />
        )}
      </main>
      
      <HistoryDrawer 
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        historyItems={history}
        onSelectItem={handleSelectHistoryItem}
        onClearHistory={handleClearHistory}
      />
      
      <footer className="w-full text-center py-6 text-xs text-muted-foreground">
        <p>Verse Simplifier • Providing understandable explanations of Vedic wisdom</p>
      </footer>
    </div>
  );
};

export default Index;
